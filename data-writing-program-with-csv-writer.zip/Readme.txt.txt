You are my warddddd!
You will do as you're toldddd!